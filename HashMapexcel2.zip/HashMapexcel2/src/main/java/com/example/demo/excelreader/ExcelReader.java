package com.example.demo.excelreader;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExcelReader {

    public static void main(String[] args) {
        // Ensure at least one argument is provided
        if (args.length < 1) {
            System.out.println("Usage: java ExcelReader <ExcelFilePath>");
            return;
        }

        // Identify the actual file path argument, skipping any --spring or similar parameters
        String excelFilePath = "C:/Users/Renu/Documents/asignmentexcel.xlsx";
        for (String arg : args) {
            if (!arg.startsWith("--")) {
                excelFilePath = arg;
                break;
            }
        }


        // Verify the file existence and validity
        File excelFile = new File(excelFilePath);
        if (!excelFile.exists() || !excelFile.isFile()) {
            System.err.println("The file does not exist or is not a valid file: " + excelFilePath);
            return;
        }

        Map<Integer, List<Object>> excelData = new HashMap<>();

        try (FileInputStream fis = new FileInputStream(excelFile);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0); // Get the first sheet

            // Iterate through each row
            for (Row row : sheet) {
                List<Object> rowData = new ArrayList<>();

                // Iterate through each cell in the row
                for (Cell cell : row) {
                    rowData.add(getCellValue(cell));
                }

                // Store the row data in the map with the row number as the key
                excelData.put(row.getRowNum(), rowData);
            }

            // Print the contents of the map
            excelData.forEach((rowNum, data) -> {
                System.out.println("Row " + rowNum + ": " + data);
            });

        } catch (IOException e) {
            System.err.println("Error reading the Excel file: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Returns the value of a cell.
     * @param cell The cell to get the value from.
     * @return The value of the cell as an Object.
     */
    private static Object getCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue();
                } else {
                    return cell.getNumericCellValue();
                }
            case BOOLEAN:
                return cell.getBooleanCellValue();
            case FORMULA:
                // Evaluate the formula and get the result
                FormulaEvaluator evaluator = cell.getSheet().getWorkbook().getCreationHelper().createFormulaEvaluator();
                return getCellValue(evaluator.evaluateInCell(cell));
            case BLANK:
                return "";
            case ERROR:
                return "ERROR";
            default:
                return "UNKNOWN";
        }
    }
}
